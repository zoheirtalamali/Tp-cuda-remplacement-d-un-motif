/******************************************************************************/
/***** Ce code Séquentiel a été écrit par TALAMALI Zoheir et TEBBAL Farah *****/
/******************* HPC ex APCI 2016/2017 ************************************/
/******************************************************************************/


#include <iostream>
#include <fstream>
#include <time.h>
#include <math.h>

#define n 3
#define N 720
#define m 3
#define M 10


using namespace std;


// Lecture des 3 matrices (matrice - motif - motif_remp) en utilisant les fichiers pour faciliter la lecture des 3 matrices.

std::ifstream fichier("image_matrice.txt");
std::ifstream fichier1("motif.txt");
std::ifstream fichier2("motif_remp.txt");
 
// Fonction de lecture de la matrice de l'image 

void remplir_matrice(int ligne,int colonne,int matrice[N][M] )
{
 int val;
    for (int i=0;i<ligne;i++)
    {
        for(int j=0;j<colonne;j++)
        {
            if (fichier>>val)

            {
            matrice[i][j]=val;
            }
        }
    }
}


// Fonction de Lecture de motif à rechercher

void remplir_matrice1(int ligne,int colonne,int matrice[n][m] )
{
 int val;
    for (int i=0;i<ligne;i++)
    {
        for(int j=0;j<colonne;j++)
        {
            if (fichier1>>val)

            {
            matrice[i][j]=val;
            }
        }
    }
}


// Fonction de Lecture de motif à remplacer

void remplir_matrice2(int ligne,int colonne,int matrice[n][m] )
{
 int val;
    for (int i=0;i<ligne;i++)
    {
        for(int j=0;j<colonne;j++)
        {
            if (fichier2>>val)

            {
            matrice[i][j]=val;
            }
        }
    }
}

int main()
{

int MAT[N][M];//déclaration de la grande matrice
int mat[n][m];//déclaration de la sous matrice à rechercher dans la grande matrice
int motif_remp[n][m];//décaration de la matrice à remplacer


int i,j,k,l,val=0;


float temps;
clock_t t1, t2;

// Déclaration de vecteur contenant les premiers indices de la matrice ou le motif a été retrouvé.

int vec[((N-n)+1)*((M-m)+1)];


// Appel des fonctions pour la lecture des 3 matrices (matrice ici appelé MAT- motif ici appelé mat- motif_remp) 

remplir_matrice(N,M,MAT);
cout << "\nLa premiere matrice a été remplie depuis le fichier ilage_matrice.txt \n";

remplir_matrice1(n,m,mat);
cout << "\nLa sous matrice à rechercher est remplie depuis le fichier motif.txt\n";

remplir_matrice2(n,m,motif_remp);
cout << "\nLa matrice fixe à remplacer est remplie depuis le fichier motif_remp.txt\n";


//Affichage de la matrice 

cout << "\n==> La matrice donnée en entrée est :\n";

for(i=0;i<N;i++)
   {cout<<"\n";
   for(j=0;j<M;j++)
       cout<<MAT[i][j]<<" ";
}
cout<<"\n\n";


//Affichage de motif

cout << "Le motif à rechercher dans l'image est :\n";

for(i=0;i<n;i++)
   {cout<<"\n";
    for(j=0;j<m;j++)
       cout<<mat[i][j]<<" ";
}
cout<<"\n";


//Affichage de motif

cout << "On remplace chaque motif trouvé dans l'image par :\n";

for(i=0;i<n;i++)
   {cout<<"\n";
   for(j=0;j<m;j++)
       cout<<motif_remp[i][j]<<" ";
}
cout<<"\n";

/* La recherche du motif dans la grande matrice (image) et la sauvegarde 
des premiers indices ou le motif a été retrouvé dans le tableau vec[] */

t1 = clock();

for(i=0;i<((N-n)+1);i++)
   for(j=0;j<((M-m)+1);j++)
       {for(k=0;k<n;k++)
   	   for(l=0; (l<m) && (mat[k][l]==MAT[k+i][l+j]);l++)
            { 
		if (l==(m-1) && k==(n-1))
		 {  
                   vec[i*((M-m)+1)+j]=1;
		 }
 
             } 
   }
cout<<"\n";

int nbr=0;// nombre de fois où le motif a été retrouvé

for(int i=0;i<((N-n)+1)*((M-m)+1);i++)
 { 
   if (vec[i]==1)
    nbr++;
   else 
    vec[i]==0;
 }


//remplacer le motif retrouvé par le motif à remplacer

 for(i=0;i<((N-n)+1)*((M-m)+1);i++)
{
	if(vec[i]==1){
			   for(k=0;k<n;k++)

			   	   {
				    for(l=0;l<m;l++)
				     { 
				      MAT[i/((M-m)+1)][i%((M-m)+1)]=motif_remp[k][l];
				      
				     }
				   }  
		      }
}


for(i=0;i<((N-n)+1);i++)
   for(j=0;j<((M-m)+1);j++)
   {
		if (vec[i*((M-m)+1)+j])
		 { 
		         for(k=0;k<n;k++)
		   	   for(l=0; l<m;l++)
			    { 
		              MAT[i+k][j+l]=motif_remp[k][l];
			     }  
		 }

   }


t2 = clock();

//affichage de nombre de fois où le motif a été retrouvé dans l'image

cout<<"==> Le motif a été retrouvé " <<nbr<<" fois dans l'image."<<"\n\n";


//Affichage de la matrice 

cout << "\nAffichage de la matrice modifiée :\n";

for(i=0;i<N;i++)
   {cout<<"\n";
   for(j=0;j<M;j++)
       cout<<MAT[i][j]<<" ";
}
cout<<"\n\n";


temps = (float)(t2-t1)/CLOCKS_PER_SEC;
cout<<"Le temps d'exécution de programme séquentiel est : "<<temps<<" secondes"<<"\n\n";

return(0);

}//FIN

